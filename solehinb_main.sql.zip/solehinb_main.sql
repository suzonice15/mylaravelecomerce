-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 01, 2020 at 10:38 AM
-- Server version: 10.3.25-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `solehinb_main`
--

-- --------------------------------------------------------

--
-- Table structure for table `adds`
--

CREATE TABLE `adds` (
  `adds_id` int(11) NOT NULL,
  `adds_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adds_link` varchar(555) COLLATE utf8mb4_unicode_ci DEFAULT '#',
  `media_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adds_type` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT 'sidebar',
  `created_time` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `adds`
--

INSERT INTO `adds` (`adds_id`, `adds_title`, `adds_link`, `media_path`, `adds_type`, `created_time`) VALUES
(1, 'tt', 'ttt', 'uploads/30-50-05-19-11-2019-2.jpg', 'home', ''),
(2, 'watch collection', 'http://demo.aynabd.net/category/watch', 'uploads/17-50-05-19-11-2019-3.jpg', 'home', 'watch collection'),
(3, 'Baby Products', 'http://demo.aynabd.net/category/helth-care', 'uploads/44-50-05-19-11-2019-1.jpg', 'home', 'Baby Products'),
(4, 'sidebar add', '#', 'uploads/05-51-05-11-11-2019-17-09-2019-offer_banner_21.png', 'sidebar', ''),
(5, 'sidebar two', '#', 'uploads/25-51-05-11-11-2019-17-09-2019-offer_banner_21.png', 'sidebar', ''),
(6, 'sidebar tree', 'd', 'uploads/42-51-05-11-11-2019-17-09-2019-offer_banner_21.png', 'sidebar', '');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_phone` varchar(13) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registered_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `email`, `user_phone`, `password`, `status`, `picture`, `registered_date`) VALUES
(12, 'Asraful islam', 'uddinashraf66@gmail.com', '01984528586', 'e10adc3949ba59abbe56e057f20f883eadmin', 'super-admin', NULL, '2020-08-24'),
(13, 'sujon', 'suzonice15@gmail.com', '4556667777', '03afefe401d493b529045b0ccd5f719fadmin', 'super-admin', NULL, '0000-00-00'),
(14, 'admin', 'a@gmail.com', '0173830567', 'c4ca4238a0b923820dcc509a6f75849badmin', 'super-admin', '1603344992.jpg', '2020-10-22');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `medium_banner` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_title` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_name` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `rank_order` int(11) DEFAULT 0,
  `seo_title` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_meta_title` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_content` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_meta_content` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registered_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `medium_banner`, `category_title`, `category_name`, `parent_id`, `status`, `rank_order`, `seo_title`, `seo_meta_title`, `seo_keywords`, `seo_content`, `seo_meta_content`, `registered_date`) VALUES
(1, NULL, 'গৃহস্থালী পণ্য', 'home-living', 0, 1, 1, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(2, NULL, 'স্বাস্থ্য সুরক্ষা  পণ্য', 'welth', 0, 1, 2, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(3, NULL, 'ইলেকট্রনিক্স পণ্য', 'ইলেকট্রনিক্স পণ্য', 0, 1, 3, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(4, NULL, 'ছেলেদের শপিং', 'ছেলেদের শপিং', 0, 1, 4, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(5, NULL, 'মেয়েদের শপিং', 'মেয়েদের শপিং', 0, 1, 4, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(6, NULL, 'বেবী অ্যান্ড কিডস', 'বেবী অ্যান্ড কিডস', 0, 1, 5, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(7, NULL, 'কসমেটিক্স', 'কসমেটিক্স', 0, 1, 6, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(8, NULL, 'মোবাইল ও গ্যাজেট', 'মোবাইল ও গ্যাজেট', 0, 1, 7, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(9, NULL, 'ঘড়ি', 'ঘড়ি', 0, 1, 8, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `courier`
--

CREATE TABLE `courier` (
  `courier_id` int(11) NOT NULL,
  `courier_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `courier_status` tinyint(4) NOT NULL COMMENT '1 for inside 2 outside',
  `created_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courier`
--

INSERT INTO `courier` (`courier_id`, `courier_name`, `courier_status`, `created_time`) VALUES
(2, 'sundarban courier', 2, '2020-07-15 07:29:35'),
(3, 'sundarban courier', 1, '2020-07-15 07:29:44'),
(4, 's a paribahan courier', 1, '2020-07-15 07:30:28'),
(5, 's a paribahan courier', 2, '2020-07-15 07:30:45'),
(6, 'parcelbd', 1, '2020-07-15 07:31:16'),
(7, 'parcelbd', 2, '2020-07-15 07:31:25');

-- --------------------------------------------------------

--
-- Table structure for table `deafult_seating`
--

CREATE TABLE `deafult_seating` (
  `default_setting_id` int(11) NOT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `site_title` varchar(200) DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  `phone` varchar(12) DEFAULT NULL,
  `phone_order` varchar(250) DEFAULT NULL,
  `shipping_charge_in_dhaka` varchar(11) DEFAULT NULL,
  `shipping_charge_out_of_dhaka` varchar(11) DEFAULT NULL,
  `default_product_terms` text DEFAULT NULL,
  `bkash` varchar(11) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deafult_seating`
--

INSERT INTO `deafult_seating` (`default_setting_id`, `logo`, `site_title`, `icon`, `phone`, `phone_order`, `shipping_charge_in_dhaka`, `shipping_charge_out_of_dhaka`, `default_product_terms`, `bkash`, `address`) VALUES
(1, '10-09-2020logo.png', NULL, '10-09-2020.png', '01300884747', '<i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\">   </i> 01300884747 <br>\r\n <i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\"> </i> 01407011239 <br>', '60', '120', NULL, '01748188268', '<ul class=\"toggle-footer\" style=\"\">\r\n                            <li class=\"media\">\r\n                                <div class=\"pull-left\">\r\n                      <span class=\"icon fa-stack fa-lg\">\r\n                      <i class=\"fa fa-map-marker f');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(2) UNSIGNED NOT NULL,
  `division_id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bn_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `division_id`, `name`, `bn_name`, `lat`, `lon`, `website`) VALUES
(1, 3, 'Dhaka', 'ঢাকা', 23.7115253, 90.4111451, 'www.dhaka.gov.bd'),
(2, 3, 'Faridpur', 'ফরিদপুর', 23.6070822, 89.8429406, 'www.faridpur.gov.bd'),
(3, 3, 'Gazipur', 'গাজীপুর', 24.0022858, 90.4264283, 'www.gazipur.gov.bd'),
(4, 3, 'Gopalganj', 'গোপালগঞ্জ', 23.0050857, 89.8266059, 'www.gopalganj.gov.bd'),
(5, 8, 'Jamalpur', 'জামালপুর', 24.937533, 89.937775, 'www.jamalpur.gov.bd'),
(6, 3, 'Kishoreganj', 'কিশোরগঞ্জ', 24.444937, 90.776575, 'www.kishoreganj.gov.bd'),
(7, 3, 'Madaripur', 'মাদারীপুর', 23.164102, 90.1896805, 'www.madaripur.gov.bd'),
(8, 3, 'Manikganj', 'মানিকগঞ্জ', 0, 0, 'www.manikganj.gov.bd'),
(9, 3, 'Munshiganj', 'মুন্সিগঞ্জ', 0, 0, 'www.munshiganj.gov.bd'),
(10, 8, 'Mymensingh', 'ময়মনসিংহ', 0, 0, 'www.mymensingh.gov.bd'),
(11, 3, 'Narayanganj', 'নারায়াণগঞ্জ', 23.63366, 90.496482, 'www.narayanganj.gov.bd'),
(12, 3, 'Narsingdi', 'নরসিংদী', 23.932233, 90.71541, 'www.narsingdi.gov.bd'),
(13, 8, 'Netrokona', 'নেত্রকোণা', 24.870955, 90.727887, 'www.netrokona.gov.bd'),
(14, 3, 'Rajbari', 'রাজবাড়ি', 23.7574305, 89.6444665, 'www.rajbari.gov.bd'),
(15, 3, 'Shariatpur', 'শরীয়তপুর', 0, 0, 'www.shariatpur.gov.bd'),
(16, 8, 'Sherpur', 'শেরপুর', 25.0204933, 90.0152966, 'www.sherpur.gov.bd'),
(17, 3, 'Tangail', 'টাঙ্গাইল', 0, 0, 'www.tangail.gov.bd'),
(18, 5, 'Bogura', 'বগুড়া', 24.8465228, 89.377755, 'www.bogra.gov.bd'),
(19, 5, 'Joypurhat', 'জয়পুরহাট', 0, 0, 'www.joypurhat.gov.bd'),
(20, 5, 'Naogaon', 'নওগাঁ', 0, 0, 'www.naogaon.gov.bd'),
(21, 5, 'Natore', 'নাটোর', 24.420556, 89.000282, 'www.natore.gov.bd'),
(22, 5, 'Chapainawabganj', 'চাঁপাইনবাবগঞ্জ', 24.5965034, 88.2775122, 'www.chapainawabganj.gov.bd'),
(23, 5, 'Pabna', 'পাবনা', 23.998524, 89.233645, 'www.pabna.gov.bd'),
(24, 5, 'Rajshahi', 'রাজশাহী', 0, 0, 'www.rajshahi.gov.bd'),
(25, 5, 'Sirajgonj', 'সিরাজগঞ্জ', 24.4533978, 89.7006815, 'www.sirajganj.gov.bd'),
(26, 6, 'Dinajpur', 'দিনাজপুর', 25.6217061, 88.6354504, 'www.dinajpur.gov.bd'),
(27, 6, 'Gaibandha', 'গাইবান্ধা', 25.328751, 89.528088, 'www.gaibandha.gov.bd'),
(28, 6, 'Kurigram', 'কুড়িগ্রাম', 25.805445, 89.636174, 'www.kurigram.gov.bd'),
(29, 6, 'Lalmonirhat', 'লালমনিরহাট', 0, 0, 'www.lalmonirhat.gov.bd'),
(30, 6, 'Nilphamari', 'নীলফামারী', 25.931794, 88.856006, 'www.nilphamari.gov.bd'),
(31, 6, 'Panchagarh', 'পঞ্চগড়', 26.3411, 88.5541606, 'www.panchagarh.gov.bd'),
(32, 6, 'Rangpur', 'রংপুর', 25.7558096, 89.244462, 'www.rangpur.gov.bd'),
(33, 6, 'Thakurgaon', 'ঠাকুরগাঁও', 26.0336945, 88.4616834, 'www.thakurgaon.gov.bd'),
(34, 1, 'Barguna', 'বরগুনা', 0, 0, 'www.barguna.gov.bd'),
(35, 1, 'Barishal', 'বরিশাল', 0, 0, 'www.barisal.gov.bd'),
(36, 1, 'Bhola', 'ভোলা', 22.685923, 90.648179, 'www.bhola.gov.bd'),
(37, 1, 'Jhalokati', 'ঝালকাঠি', 0, 0, 'www.jhalakathi.gov.bd'),
(38, 1, 'Patuakhali', 'পটুয়াখালী', 22.3596316, 90.3298712, 'www.patuakhali.gov.bd'),
(39, 1, 'Pirojpur', 'পিরোজপুর', 0, 0, 'www.pirojpur.gov.bd'),
(40, 2, 'Bandarban', 'বান্দরবান', 22.1953275, 92.2183773, 'www.bandarban.gov.bd'),
(41, 2, 'Brahmanbaria', 'ব্রাহ্মণবাড়িয়া', 23.9570904, 91.1119286, 'www.brahmanbaria.gov.bd'),
(42, 2, 'Chandpur', 'চাঁদপুর', 23.2332585, 90.6712912, 'www.chandpur.gov.bd'),
(43, 2, 'Chattogram', 'চট্টগ্রাম', 22.335109, 91.834073, 'www.chittagong.gov.bd'),
(44, 2, 'Cumilla', 'কুমিল্লা', 23.4682747, 91.1788135, 'www.comilla.gov.bd'),
(45, 2, 'Cox\'s Bazar', 'কক্স বাজার', 0, 0, 'www.coxsbazar.gov.bd'),
(46, 2, 'Feni', 'ফেনী', 23.023231, 91.3840844, 'www.feni.gov.bd'),
(47, 2, 'Khagrachhari', 'খাগড়াছড়ি', 23.119285, 91.984663, 'www.khagrachhari.gov.bd'),
(48, 2, 'Lakshmipur', 'লক্ষ্মীপুর', 22.942477, 90.841184, 'www.lakshmipur.gov.bd'),
(49, 2, 'Noakhali', 'নোয়াখালী', 22.869563, 91.099398, 'www.noakhali.gov.bd'),
(50, 2, 'Rangamati', 'রাঙ্গামাটি', 0, 0, 'www.rangamati.gov.bd'),
(51, 7, 'Habiganj', 'হবিগঞ্জ', 24.374945, 91.41553, 'www.habiganj.gov.bd'),
(52, 7, 'Moulvibazar', 'মৌলভীবাজার', 24.482934, 91.777417, 'www.moulvibazar.gov.bd'),
(53, 7, 'Sunamganj', 'সুনামগঞ্জ', 25.0658042, 91.3950115, 'www.sunamganj.gov.bd'),
(54, 7, 'Sylhet', 'সিলেট', 24.8897956, 91.8697894, 'www.sylhet.gov.bd'),
(55, 4, 'Bagerhat', 'বাগেরহাট', 22.651568, 89.785938, 'www.bagerhat.gov.bd'),
(56, 4, 'Chuadanga', 'চুয়াডাঙ্গা', 23.6401961, 88.841841, 'www.chuadanga.gov.bd'),
(57, 4, 'Jashore', 'যশোর', 23.16643, 89.2081126, 'www.jessore.gov.bd'),
(58, 4, 'Jhenaidah', 'ঝিনাইদহ', 23.5448176, 89.1539213, 'www.jhenaidah.gov.bd'),
(59, 4, 'Khulna', 'খুলনা', 22.815774, 89.568679, 'www.khulna.gov.bd'),
(60, 4, 'Kushtia', 'কুষ্টিয়া', 23.901258, 89.120482, 'www.kushtia.gov.bd'),
(61, 4, 'Magura', 'মাগুরা', 23.487337, 89.419956, 'www.magura.gov.bd'),
(62, 4, 'Meherpur', 'মেহেরপুর', 23.762213, 88.631821, 'www.meherpur.gov.bd'),
(63, 4, 'Narail', 'নড়াইল', 23.172534, 89.512672, 'www.narail.gov.bd'),
(64, 4, 'Satkhira', 'সাতক্ষীরা', 0, 0, 'www.satkhira.gov.bd');

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bn_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `name`, `bn_name`) VALUES
(1, 'Barishal', 'বরিশাল'),
(2, 'Chattogram', 'চট্টগ্রাম'),
(3, 'Dhaka', 'ঢাকা'),
(4, 'Khulna', 'খুলনা'),
(5, 'Rajshahi', 'রাজশাহী'),
(6, 'Rangpur', 'রংপুর'),
(7, 'Sylhet', 'সিলেট'),
(8, 'Mymensingh', 'ময়মনসিংহ');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `expense_id` int(11) NOT NULL,
  `expense_type` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_title` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_total` float DEFAULT NULL,
  `expense_data` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_summary` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expense_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_category`
--

CREATE TABLE `expense_category` (
  `expense_cat_id` int(11) NOT NULL,
  `expense_cat_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hitcounter`
--

CREATE TABLE `hitcounter` (
  `hitcounter_id` int(11) NOT NULL,
  `client_ip` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `platform` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agent` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `homeslider`
--

CREATE TABLE `homeslider` (
  `homeslider_id` int(11) NOT NULL,
  `homeslider_title` varchar(555) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#',
  `homeslider_text` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_url` varchar(555) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#',
  `homeslider_picture` varchar(555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `homeslider`
--

INSERT INTO `homeslider` (`homeslider_id`, `homeslider_title`, `homeslider_text`, `target_url`, `homeslider_picture`, `created_time`, `modified_time`, `status`) VALUES
(1, '.', NULL, 'https://www.sohojbuy.com/category/health--beautyes', '1596983390.jpg', '2020-07-02 00:00:00', '2020-08-09 00:00:00', 1),
(5, '.', NULL, 'https://www.sohojbuy.com/category/kitchen--dining', '1596983358.jpg', '2020-07-05 00:00:00', '2020-08-09 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `inquiry_id` int(11) NOT NULL,
  `name` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`inquiry_id`, `name`, `phone`, `subject`, `status`, `message`, `created_time`, `modified_time`) VALUES
(4, 'Md Shahinul Islam Suzon', '01731692631', 'I need html template', '0', 'ddd', '2019-12-02 04:33:06', '0000-00-00 00:00:00'),
(5, 'Md Shahinul Islam Suzon', '01731692631', 'I need html template', '0', 'ddd', '2019-12-02 09:35:15', '0000-00-00 00:00:00'),
(6, 'Md Shahinul Islam Suzon', '01731692631', 'I need html template', '1', 'fffffff', '2019-12-02 09:45:07', '0000-00-00 00:00:00'),
(7, 'Md Shahinul Islam Suzon', '01711000000', 'I need html template', '0', 'rrr', '2019-12-02 09:45:41', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `media_id` int(11) NOT NULL,
  `media_title` varchar(555) COLLATE utf8mb4_unicode_ci DEFAULT '#',
  `product_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `media_path` varchar(555) COLLATE utf8mb4_unicode_ci NOT NULL,
  `media_type` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_id` int(15) DEFAULT NULL,
  `created_time` datetime NOT NULL,
  `modified_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`media_id`, `media_title`, `product_code`, `media_path`, `media_type`, `product_id`, `created_time`, `modified_time`) VALUES
(1, 'Baby bouncer product', '1', 'uploads/1/1.1.webp', 'featured_image', 1, '2020-08-19 00:13:38', '2020-08-19 00:13:38'),
(2, 'Baby bouncer product', '1', 'uploads/1/35.4081-1-min.webp', 'galary_image1', 1, '2020-08-19 00:07:26', '2020-08-19 00:07:26'),
(3, 'Baby bouncer product', '1', 'uploads/1/39.4081-2-min.webp', 'galary_image2', 1, '2020-08-19 00:07:26', '2020-08-19 00:07:26'),
(4, 'প্রেসার পরিমাপ করার যন্ত্র', 'dFM5003', 'uploads/2/2.BP-final.jpg', 'featured_image', 2, '2020-08-22 14:58:49', '2020-08-22 14:58:49'),
(5, 'প্রেসার পরিমাপ করার যন্ত্র', 'dFM5003', 'uploads/2/63.BP-final.jpg', 'galary_image1', 2, '2020-08-22 14:58:49', '2020-08-22 14:58:49'),
(6, 'প্রেসার পরিমাপ করার যন্ত্র', 'daFM5003', 'uploads/3/3.BP-final (3).webp', 'featured_image', 3, '2020-08-31 09:02:52', '2020-08-31 09:02:52'),
(7, 'ধুলাবালি পরিষ্কার করার যন্ত্র', '0003', 'uploads/4/4.go-duster-.webp', 'featured_image', 4, '2020-08-31 09:09:41', '2020-08-31 09:09:41'),
(8, 'ধুলাবালি পরিষ্কার করার যন্ত্র', '0003', 'uploads/4/84.NICEYARD-Soft-Microfiber-Window-Bookshelf-Dust-Cleaner-Brush-For-Home-Furniture-Car-Multifunctional-Electric-Feather-Duster.jpg_q50.webp', 'galary_image1', 4, '2020-08-31 09:09:42', '2020-08-31 09:09:42'),
(9, 'রিচার্জেবল মিনি ক্যামেরা', '0004', 'uploads/5/5.2020-Newest-SQ11-Mini-Camera-Micro-Video-Recorder-Digital-Cam-Sensor-Night-Vision-Camcorder-HD-960.jpg_q50-Copy.webp', 'featured_image', 5, '2020-08-31 09:17:59', '2020-08-31 09:17:59'),
(10, '9 in 1 সবজি কাটা ধোয়া এক মেশিনে', '0005', 'uploads/6/6.vc.webp', 'featured_image', 6, '2020-08-31 09:24:43', '2020-08-31 09:24:43'),
(11, 'রুম ঝাড়ু দেওয়ার মেশিন', 'daSM-360', 'uploads/7/7.raw-1.webp', 'featured_image', 7, '2020-08-31 09:28:47', '2020-08-31 09:28:47'),
(12, 'দুধ,ভাতের ফেন উতলিয়ে পরে যাওয়ার দিন শেষ', 'DB-01', 'uploads/8/8.milk.webp', 'featured_image', 8, '2020-09-03 09:23:10', '2020-09-03 09:23:10'),
(13, 'দুধ,ভাতের ফেন উতলিয়ে পরে যাওয়ার দিন শেষ', 'DB-01', 'uploads/8/93.milk-2.webp', 'galary_image1', 8, '2020-09-03 09:23:10', '2020-09-03 09:23:10'),
(14, 'মাল্টি ফাংশন ফুট বাথ স্পা মাসাজার', 'FBM-01 danpit', 'uploads/9/9.foot.webp', 'featured_image', 9, '2020-09-03 09:35:03', '2020-09-03 09:35:03'),
(15, 'Koti 99', 'tazir k-99', 'uploads/10/10.ezgif.com-gif-maker(3).webp', 'featured_image', 10, '2020-09-03 12:51:36', '2020-09-03 12:51:36'),
(16, 'Koti 94', 'tazir sb225', 'uploads/11/11.ezgif.com-gif-maker(4).webp', 'featured_image', 11, '2020-09-03 13:09:31', '2020-09-03 13:09:31'),
(17, 'koti 10', 'tazir -10', 'uploads/12/12.ezgif.com-gif-maker(5).webp', 'featured_image', 12, '2020-09-03 13:05:18', '2020-09-03 13:05:18'),
(18, 'Koti 99', 'tazir k99', 'uploads/13/13.ezgif.com-gif-maker(1).webp', 'featured_image', 13, '2020-09-03 14:28:16', '2020-09-03 14:28:16'),
(19, 'Koti 99', 'tazir 99', 'uploads/13/14.ezgif.com-gif-maker(3).webp', 'featured_image', 14, '2020-09-03 14:42:59', '2020-09-03 14:42:59'),
(20, 'Koti-82', 'tazir 82', 'uploads/15/15.ezgif.com-gif-maker (1).webp', 'featured_image', 15, '2020-09-03 14:50:01', '2020-09-03 14:50:01'),
(21, 'kr 506', 'tazir 506', 'uploads/16/16.ezgif.com-gif-maker (2).webp', 'featured_image', 16, '2020-09-03 15:41:29', '2020-09-03 15:41:29'),
(22, 'Khimer 505', 'tazir505', 'uploads/17/17.ezgif.com-gif-maker (3).webp', 'featured_image', 17, '2020-09-03 15:47:16', '2020-09-03 15:47:16'),
(23, '502', 'tazir 502', 'uploads/18/18.ezgif.com-gif-maker (4).webp', 'featured_image', 18, '2020-09-03 16:04:40', '2020-09-03 16:04:40'),
(24, '137', 'tazir 137', 'uploads/19/19.137 2950.jpg', 'featured_image', 19, '2020-09-03 16:11:30', '2020-09-03 16:11:30'),
(25, 'dw 70', 'dw 70 tazir', 'uploads/20/20.ezgif.com-gif-maker (6).webp', 'featured_image', 20, '2020-09-03 16:19:17', '2020-09-03 16:19:17'),
(26, 'Borka 2302', 'tazir  Borka 2302', 'uploads/21/21.ezgif.com-gif-maker (7).webp', 'featured_image', 21, '2020-09-03 16:29:42', '2020-09-03 16:29:42'),
(27, '233', 'tazir 233', 'uploads/22/22.ezgif.com-gif-maker (8).webp', 'featured_image', 22, '2020-09-03 16:33:36', '2020-09-03 16:33:36'),
(28, '504', 'tazir504', 'uploads/23/23.ezgif.com-gif-maker (9).webp', 'featured_image', 23, '2020-09-03 16:37:23', '2020-09-03 16:37:23'),
(29, '501', 'tazir 501', 'uploads/24/24.ezgif.com-gif-maker (10).webp', 'featured_image', 24, '2020-09-03 16:40:29', '2020-09-03 16:40:29'),
(30, '503', 'tazir 503', 'uploads/25/25.ezgif.com-gif-maker (11).webp', 'featured_image', 25, '2020-09-03 16:42:53', '2020-09-03 16:42:53'),
(31, '508', 'tazir 508', 'uploads/26/26.ezgif.com-gif-maker (12).webp', 'featured_image', 26, '2020-09-03 16:45:24', '2020-09-03 16:45:24'),
(32, 'M3 Water Proof স্মার্ট রিস্ট ব্যান্ড', 'M3 Water Proof স্মার্ট রিস্ট ব্যান্ড-1', 'uploads/27/27.ezgif.com-gif-maker.webp', 'featured_image', 27, '2020-09-10 09:30:51', '2020-09-10 09:30:51'),
(33, 'facke', '0027', 'uploads/28/28.83776730_2545667262345767_6942520231155728384_o.jpg', 'featured_image', 28, '2020-10-21 23:02:46', '2020-10-21 23:02:46');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

CREATE TABLE `newsletter` (
  `newsletter_id` int(11) NOT NULL,
  `newsletter_email` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `newsletter`
--

INSERT INTO `newsletter` (`newsletter_id`, `newsletter_email`, `created_time`, `status`) VALUES
(9, 'ss@hhhh.jjj', '2019-12-12 09:10:39', 0),
(10, 'ssf@ggg.jjj', '2019-12-17 03:22:42', 0),
(11, 'ssf@ggg.jjj', '2019-12-17 03:22:45', 0),
(12, 'ff@ffffgg.jjjj', '2020-01-04 05:12:22', 0);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `option_id` int(11) NOT NULL,
  `option_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`option_id`, `option_name`, `option_value`) VALUES
(59, 'home_page_category_id', '58,65'),
(60, 'logo', 'https://demo.bestearnidea.com/wp-content/uploads/file/logo-gif.gif'),
(61, 'icon', 'https://sohojbuy.com/public/uploads/logo f.png'),
(62, 'site_title', 'Solehin Online Shopping'),
(63, 'order_image', NULL),
(64, 'phone', '01300884747'),
(65, 'phone_order', '<i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\">   </i> 01300884747 <br>\r\n <i class=\"fa fa-phone-square\" style=\"padding-left:20px;color: green;\"> </i> 01407011239 <br>'),
(66, 'address', '<ul class=\"toggle-footer\" style=\"\">\r\n                            <li class=\"media\">\r\n                                <div class=\"pull-left\">\r\n                      <span class=\"icon fa-stack fa-lg\">\r\n                      <i class=\"fa fa-map-marker fa-stack-1x fa-inverse\"></i>\r\n                      </span>\r\n                                </div>\r\n                                <div class=\"media-body\">\r\n                                    <p>Office no 1417, Level 13, Shah Ali Plaza, Mirpur 10, Dhaka</p>\r\n                                </div>\r\n                            </li>\r\n                            <li class=\"media\">\r\n                                <div class=\"pull-left\">\r\n                      <span class=\"icon fa-stack fa-lg\">\r\n                      <i class=\"fa fa-mobile fa-stack-1x fa-inverse\"></i>\r\n                      </span>\r\n                                </div>\r\n                                <div class=\"media-body\">\r\n                                    <p>01300884747<br>01300884747</p>\r\n                                </div>\r\n                            </li>\r\n                            <li class=\"media\">\r\n                                <div class=\"pull-left\">\r\n                      <span class=\"icon fa-stack fa-lg\">\r\n                      <i class=\"fa fa-envelope fa-stack-1x fa-inverse\"></i>\r\n                      </span>\r\n                                </div>\r\n                                <div class=\"media-body\">\r\n                                    <span><a href=\"#\">support@sohojbuy.com</a></span>\r\n                                </div>\r\n                            </li>\r\n                        </ul>'),
(67, 'admin_email', 'info@sohojbuy.com'),
(68, 'shipping_charge_in_dhaka', '60'),
(69, 'shipping_charge_out_of_dhaka', '120'),
(70, 'footer', NULL),
(71, 'google_map', NULL),
(72, 'copyright', NULL),
(73, 'default_product_terms', NULL),
(74, 'home_cat_section', '1,18,2,102,4,9,16,113,124'),
(75, 'home_seo_title', 'Sohoj Online Shopping'),
(76, 'home_seo_content', NULL),
(77, 'home_seo_keywords', NULL),
(78, 'home_about_title', NULL),
(79, 'home_about_content', NULL),
(80, 'bkash', '01748188268'),
(81, 'facebook', 'https://www.facebook.com/sohojbuyshop'),
(82, 'youtube', 'https://www.youtube.com/channel/UCWA3XLqrBLNItdEXNAcZVSA'),
(83, 'twitter', NULL),
(84, 'linked', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_data`
--

CREATE TABLE `order_data` (
  `order_id` bigint(200) NOT NULL,
  `created_by` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT 'customer',
  `staff_id` int(11) DEFAULT NULL,
  `order_total` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_charge` int(11) DEFAULT NULL,
  `discount_price` int(11) NOT NULL DEFAULT 0,
  `advabced_price` int(11) NOT NULL DEFAULT 0,
  `order_status` varchar(55) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `payment_type` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `products` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `courier_service` varchar(155) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipment_time` datetime DEFAULT NULL,
  `created_time` datetime NOT NULL,
  `order_date` date NOT NULL,
  `modified_time` datetime DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_email` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delevery_address` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_area` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_note` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_data`
--

INSERT INTO `order_data` (`order_id`, `created_by`, `staff_id`, `order_total`, `shipping_charge`, `discount_price`, `advabced_price`, `order_status`, `payment_type`, `products`, `courier_service`, `shipment_time`, `created_time`, `order_date`, `modified_time`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `delevery_address`, `order_area`, `order_note`) VALUES
(9, 'Customer', 0, '9220', 120, 0, 0, 'completed', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:88;a:5:{s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:84:\"https://www.sohojbuy.com/public/uploads/88/small/88.TP-Link Archer C9 AC1900Mbps.jpg\";s:5:\"price\";s:4:\"9100\";s:4:\"name\";s:44:\"TP-Link Archer C9 AC1900Mbps  Gigabit Router\";s:8:\"subtotal\";s:4:\"9100\";}}}', NULL, '2020-07-08 00:00:00', '2020-07-14 11:40:56', '2020-07-14', '2020-07-15 07:33:53', 'sujon', '01738305671', 'suzonice15@gmail.com', 'dhaka', NULL, 'outside', NULL),
(10, 'Customer', 0, '1760', 60, 0, 0, 'completed', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:53;a:5:{s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:101:\"https://www.sohojbuy.com/public/uploads/53/small/53.Infrared Foan Vibration Heating Foot Massager.jpg\";s:5:\"price\";s:4:\"1700\";s:4:\"name\";s:45:\"Infrared Foan Vibration Heating Foot Massager\";s:8:\"subtotal\";s:4:\"1700\";}}}', NULL, '2020-07-08 00:00:00', '2020-07-14 01:17:57', '2020-07-14', '2020-07-15 07:33:05', 'syed Salman', '01911582777', 'salman@gmail.com', 'Flat-A8, Address 16/3 Lake circus, kalabagan. (Rangs er goli)', NULL, 'inside', NULL),
(11, 'Customer', 0, '1770', 120, 0, 0, 'completed', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:59;a:5:{s:3:\"qty\";s:1:\"1\";s:14:\"featured_image\";s:96:\"https://www.sohojbuy.com/public/uploads/59/small/59.electronic-blood-pressure-monitor-RAK283.jpg\";s:5:\"price\";s:4:\"1650\";s:4:\"name\";s:30:\"Blood Pressure Monitor, RAK283\";s:8:\"subtotal\";s:4:\"1650\";}}}', NULL, '2020-07-06 00:00:00', '2020-07-15 07:51:27', '2020-07-15', '2020-07-15 07:52:01', 'Mohammad Naimul Hossain', '01721840695', 'Naimul@gmail.com', '#H 2 R #9 North khulshi R/A, khulshi, Chittagong', NULL, 'outside', NULL),
(12, 'Customer', 0, '1110', 120, 0, 0, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:4;a:5:{s:14:\"featured_image\";s:61:\"http://solehinbd.com/public/uploads/4/small/4.go-duster-.webp\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"990\";s:8:\"subtotal\";s:3:\"990\";s:4:\"name\";s:81:\"ধুলাবালি পরিষ্কার করার যন্ত্র\";}}}', NULL, NULL, '2020-09-09 10:46:41', '2020-09-09', NULL, 'ssssss', '3333333ee', 'wwwwwww@ffff', 'ffffffff', NULL, 'outside', NULL),
(13, 'Customer', 0, '1010', 120, 0, 0, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:7;a:5:{s:14:\"featured_image\";s:56:\"http://solehinbd.com/public/uploads/7/small/7.raw-1.webp\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:3:\"890\";s:8:\"subtotal\";s:3:\"890\";s:4:\"name\";s:63:\"রুম ঝাড়ু দেওয়ার মেশিন\";}}}', NULL, NULL, '2020-09-15 12:38:44', '2020-09-15', NULL, 'Product den', '017384442', 'suzonice15@gmail.com', 'Mirpur 2', NULL, 'outside', NULL),
(14, 'Customer', 0, '2960', 60, 0, 0, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:18;a:5:{s:14:\"featured_image\";s:76:\"http://solehinbd.com/public/uploads/18/small/18.ezgif.com-gif-maker (4).webp\";s:3:\"qty\";s:1:\"2\";s:5:\"price\";s:4:\"1450\";s:8:\"subtotal\";s:4:\"2900\";s:4:\"name\";s:3:\"502\";}}}', NULL, NULL, '2020-10-07 03:11:23', '2020-10-07', NULL, 'Sujon Ali', '01738305670', 'suzonice15@gmail.com', 'Mirpur 2', NULL, 'inside', NULL),
(15, 'Customer', 0, '1950', 60, 0, 0, 'new', 'cash_on_delivery', 'a:1:{s:5:\"items\";a:1:{i:9;a:5:{s:14:\"featured_image\";s:55:\"http://solehinbd.com/public/uploads/9/small/9.foot.webp\";s:3:\"qty\";s:1:\"1\";s:5:\"price\";s:4:\"1890\";s:8:\"subtotal\";s:4:\"1890\";s:4:\"name\";s:89:\"মাল্টি ফাংশন ফুট বাথ স্পা মাসাজার\";}}}', NULL, NULL, '2020-10-07 05:33:27', '2020-10-07', NULL, 'Sujon Ali', '01738305670', 'suzonice15@gmail.com', 'Mirpur 2', NULL, 'inside', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`page_id`, `page_name`, `page_link`, `page_content`, `created_time`) VALUES
(3, 'Contact us', 'contact-us', '<p>test</p>', '2019-10-07 10:18:01'),
(4, 'About Us', 'about-us', '<h1><strong>About Shohojbuy</strong></h1>\r\n\r\n<hr />\r\n<p><strong>Shohojbuy</strong>.com is the ultimate online shopping destination in Bangladesh, offering completely hassle-free shopping experience through secure and trusted payment gateways and quickest delivery service. We are offering you trendy and reliable shopping with all your favorite brands and more. Now shopping is much more easier, faster and joyous. We are here to help you make the right choice. <strong>Shohojbuy</strong>.com is a concern of Jibonpata.</p>\r\n\r\n<p><strong>Shohojbuy&nbsp;</strong>showcases only Original products from all categories such as clothing, footwear, jewellery, accessories, electronics, home appliance, gadgets, health &amp; beauty and still counting!&nbsp; Our products are exclusively selected for you. <strong>Shohojbuy&nbsp;</strong>have all the stuffs that you need under one umbrella at incredible prices.</p>\r\n\r\n<p>In tune with the vision <strong>&ldquo;Digital Bangladesh&rdquo;</strong>, <strong>Shohojbuy</strong>.com opens the doorway for everybody to shop over the Internet sitting at home. We are constantly updating our product lines, services and special offers that fits with your requirement. We provide on-time delivery across the nation and quick resolution of any concerns. Customer support and satisfaction is our main strength. We are working hard every moment to make your online shopping secure &amp; enjoyable.&nbsp;</p>', '2019-11-13 11:56:27'),
(5, 'TERMS & CONDITIONS', 'terms', '<p>কীভাবে মূল্য ফেরত নেবেন অনলাইন পেমেণ্ট এর ক্ষেত্রে অতিরিক্ত মূল্য পরিশোধিত হলে ২৪ ঘণ্টার মধ্যে জানাতে হবে । এক্ষেত্রে&nbsp; এ মেইল করে জানানোর জন্য অনুরোধ করা হচ্ছে । ১. নষ্ট বা ক্ষতিগ্রস্ত পণ্যের ক্ষেত্রে পণ্য গ্রহন না করে পন্যবাহকের কাছে পণ্য ফেরত দেবার জন্য বলা হচ্ছে এবং আমাদেরকে টেলিফোন/ ইমেইল করে অবহিত করার জন্য অনুরোধ করা হচ্ছে। ২. নষ্ট পণ্য সাথে সাথে বাহকের কাছে ফেরত দিতে সমর্থ না হলে পরবর্তীতে ফেরত দেবার ক্ষেত্রে যাবতীয় পরিবহন খরচ ক্রেতাকে বহন করতে হবে। ৩. ব্যবহার করা পণ্যের ক্ষেত্রে কোনভাবেই মূল্য ফেরত দেওয়া হবে না। ৪. ট্রাভেল ডিল এর ক্ষেত্রে যাত্রা বাতিল করে মূল্য ফেরত নেবার জন্য নির্দিষ্ট সময়ের মধ্যে আমাদেরকে অবহিত করার জন্য অনুরোধ করা হচ্ছে । ৫. পরিশোধকৃত মূল্য ফেরত নেবার ক্ষেত্রে অবশ্যই ক্রেতাকে আমাদের অফিসে এসে মূল্য ফেরত নিতে হবে (অনলাইন পেমেন্ট এর ক্ষেএে প্রযোজ্য নয়)। ৬. মূল্য ফেরত পাবার জন্য অবহিত করার পর ৭ থেকে ২১ দিন পর্যন্ত অপেক্ষা করতে হতে পারে। ৭. অনলাইন পেমেন্ট ফেরত নেবার ক্ষেত্রে ক্রেতার ব্যাংক স্টেটমেন্ট দিতে হতে পারে। .</p>', '2019-10-06 07:30:58'),
(6, 'Track Your Order ', 'page_track', '<ul style=\"list-style-type:circle\">\r\n	<li>1.আপনার অর্ডারের আপডেট জানতে নিচের বক্সে অর্ডার নাম্বার অথবা আপনার মোবাইল নাম্বার দিয়ে Track order বাটনে চাপুন।</li>\r\n	<li>2.To get latest update about your order please enter your order number or mobile number and click on the Track order button</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n', '2019-12-01 12:10:59'),
(8, 'Return Policy', 'return_policy', '<p>hh</p>', '2019-09-01 07:07:54'),
(9, 'Company', 'company', '<p>ddd</p>', '2019-11-10 03:33:59'),
(10, 'Customer  service', 'customer-service', '<p>ddd</p>\r\n\r\n<p>gggg</p>', '2020-07-05 08:13:01'),
(11, 'Guide line', 'shopping', '<p>ffff</p>', '2020-07-14 06:56:48'),
(12, 'help center', 'help-center', '<p>test</p>', '2020-07-14 06:59:33'),
(13, 'FAQ', 'faq', '<p>ffff</p>', '2020-07-14 07:00:03');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `product_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` double DEFAULT NULL,
  `discount_price` int(11) DEFAULT 0,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1 COMMENT '1 active 0 in active',
  `product_type` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT 'general',
  `modified_time` datetime NOT NULL,
  `folder` int(11) NOT NULL,
  `feasured_image` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_title`, `product_name`, `product_price`, `discount_price`, `sku`, `status`, `product_type`, `modified_time`, `folder`, `feasured_image`) VALUES
(1, 'Baby bouncer product', 'baby-bouncer-product', 2600, 1600, '1', 1, 'general', '2020-08-19 00:13:38', 1, '1.1.webp'),
(3, 'প্রেসার পরিমাপ করার যন্ত্র', 'pressar-weght[-metice', 2150, 1590, 'daFM5003', 1, 'general', '2020-08-31 09:02:52', 3, '3.BP-final (3).webp'),
(4, 'ধুলাবালি পরিষ্কার করার যন্ত্র', 'cleaning-device', 1050, 990, 'daGD-01', 1, 'general', '2020-08-31 09:11:33', 4, '4.go-duster-.webp'),
(5, 'রিচার্জেবল মিনি ক্যামেরা', 'camera', 1250, 990, 'daEG8017', 1, 'general', '2020-08-31 09:19:04', 5, '5.2020-Newest-SQ11-Mini-Camera-Micro-Video-Recorder-Digital-Cam-Sensor-Night-Vision-Camcorder-HD-960.jpg_q50-Copy.webp'),
(6, '9 in 1 সবজি কাটা ধোয়া এক মেশিনে', '9-in-1', 1250, 950, '0005', 1, 'general', '2020-08-31 09:24:42', 6, '6.vc.webp'),
(7, 'রুম ঝাড়ু দেওয়ার মেশিন', 'fff', 1490, 890, 'daSM-360', 1, 'general', '2020-09-10 20:14:17', 7, '7.raw-1.webp'),
(8, 'দুধ,ভাতের ফেন উতলিয়ে পরে যাওয়ার দিন শেষ', 'milk-rich', 650, NULL, 'DB-01', 1, 'general', '2020-09-03 09:23:09', 8, '8.milk.webp'),
(9, 'মাল্টি ফাংশন ফুট বাথ স্পা মাসাজার', 'multi function foot bath', 2400, 1890, 'FBM-01 danpit', 1, 'general', '2020-09-03 09:40:34', 9, '9.foot.webp'),
(10, 'Koti 99', 'koti-99', 0, NULL, 'tazir k-99', 1, 'general', '2020-09-03 12:51:36', 10, '10.ezgif.com-gif-maker(3).webp'),
(11, 'Koti 94', 'koti-94', 0, NULL, 'tazir sb225', 1, 'general', '2020-09-03 13:09:31', 11, '11.ezgif.com-gif-maker(4).webp'),
(12, 'koti 10', 'koti-10', 1000, NULL, 'tazir -10', 1, 'general', '2020-09-03 13:05:18', 12, '12.ezgif.com-gif-maker(5).webp'),
(14, 'Koti 99', 'koti-99es', 990, NULL, 'tazir 99', 1, 'general', '2020-09-03 14:42:58', 13, '14.ezgif.com-gif-maker(3).webp'),
(15, 'Koti-82', 'koti-82', 820, NULL, 'tazir 82', 1, 'general', '2020-09-03 14:50:00', 15, '15.ezgif.com-gif-maker (1).webp'),
(16, 'kr 506', 'kr-506', 1450, NULL, 'tazir 506', 1, 'general', '2020-09-03 15:41:28', 16, '16.ezgif.com-gif-maker (2).webp'),
(17, 'Khimer 505', 'khimer-505', 1450, NULL, 'tazir505', 1, 'general', '2020-09-03 15:53:55', 17, '17.ezgif.com-gif-maker (3).webp'),
(18, '502', '502', 1450, NULL, 'tazir 502', 1, 'first', '2020-10-29 14:15:04', 18, '18.ezgif.com-gif-maker (4).webp'),
(19, '137', '137', 2950, NULL, 'tazir 137', 1, 'first', '2020-10-29 14:15:14', 19, '19.137 2950.jpg'),
(20, 'dw 70', 'dw-70', 3880, NULL, 'dw 70 tazir', 1, 'general', '2020-09-03 16:19:17', 20, '20.ezgif.com-gif-maker (6).webp'),
(21, 'Borka 2302', '-borka-2302', 2600, NULL, 'tazir  Borka 2302', 1, 'general', '2020-09-03 16:47:52', 21, '21.ezgif.com-gif-maker (7).webp'),
(22, '233', '233', 3450, NULL, 'tazir 233', 1, 'general', '2020-09-03 16:47:39', 22, '22.ezgif.com-gif-maker (8).webp'),
(23, '504', '504', 1450, NULL, 'tazir504', 1, 'first', '2020-10-29 14:18:17', 23, '23.ezgif.com-gif-maker (9).webp'),
(24, '501', '501', 1450, 1400, 'tazir 501', 1, 'general', '2020-10-29 14:16:15', 24, '24.ezgif.com-gif-maker (10).webp'),
(25, '503', '503', 1450, 1400, 'tazir 503', 1, 'general', '2020-10-29 14:15:58', 25, '25.ezgif.com-gif-maker (11).webp'),
(26, 'style borka', 'style-borka', 1450, 1400, '508', 1, 'last', '2020-10-29 14:52:06', 26, '26.ezgif.com-gif-maker (12).webp'),
(27, 'M3 Water Proof স্মার্ট রিস্ট ব্যান্ড', 'm3-water-proof---', 1350, 1150, '254', 1, 'last', '2020-10-29 14:52:23', 27, '27.ezgif.com-gif-maker.webp');

-- --------------------------------------------------------

--
-- Table structure for table `product_category_relation`
--

CREATE TABLE `product_category_relation` (
  `product_category_relation_id` bigint(250) NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `category_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_category_relation`
--

INSERT INTO `product_category_relation` (`product_category_relation_id`, `product_id`, `category_id`) VALUES
(3, 1, 6),
(10, 3, 2),
(11, 3, 3),
(13, 4, 1),
(16, 5, 3),
(17, 6, 1),
(18, 6, 3),
(49, 7, 1),
(20, 8, 1),
(22, 9, 1),
(23, 9, 2),
(24, 16, 5),
(25, 17, 5),
(60, 18, 5),
(61, 19, 5),
(29, 20, 5),
(47, 21, 5),
(46, 22, 5),
(65, 23, 5),
(64, 24, 5),
(63, 25, 5),
(66, 26, 5),
(67, 27, 1),
(68, 27, 9);

-- --------------------------------------------------------

--
-- Table structure for table `product_relation`
--

CREATE TABLE `product_relation` (
  `product_relation_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `purchase_price` int(11) DEFAULT NULL,
  `product_description` text DEFAULT NULL,
  `product_stock` int(11) DEFAULT NULL,
  `product_video` varchar(50) DEFAULT NULL,
  `product_type` varchar(50) NOT NULL,
  `galary_image_1` varchar(250) DEFAULT NULL,
  `galary_image_2` varchar(250) DEFAULT NULL,
  `galary_image_3` varchar(250) DEFAULT NULL,
  `galary_image_4` varchar(250) DEFAULT NULL,
  `galary_image_5` varchar(250) DEFAULT NULL,
  `created_time` datetime NOT NULL,
  `seo_title` varchar(250) DEFAULT NULL,
  `seo_keywords` varchar(400) DEFAULT NULL,
  `seo_content` text DEFAULT NULL,
  `delivery_in_dhaka` int(10) DEFAULT NULL,
  `delivery_out_dhaka` int(10) DEFAULT NULL,
  `website` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_relation`
--

INSERT INTO `product_relation` (`product_relation_id`, `product_id`, `purchase_price`, `product_description`, `product_stock`, `product_video`, `product_type`, `galary_image_1`, `galary_image_2`, `galary_image_3`, `galary_image_4`, `galary_image_5`, `created_time`, `seo_title`, `seo_keywords`, `seo_content`, `delivery_in_dhaka`, `delivery_out_dhaka`, `website`) VALUES
(1, 1, 1000, NULL, 12, NULL, '', '39.2.webp', '36.3.webp', NULL, NULL, NULL, '2020-08-19 00:13:38', NULL, NULL, NULL, 60, 120, ''),
(3, 3, 1000, '<h3 style=\"text-align:center\"><strong>DIGITAL BLOOD PRESSURE MACHINE</strong></h3>\r\n\r\n<div class=\"pdp-product-detail\">\r\n<div class=\"pdp-product-desc\">\r\n<div class=\"html-content pdp-product-highlights\">\r\n<ul>\r\n	<li>Product Type : Digital BP Upper Arm Monitor</li>\r\n	<li>Easy, One-Touch Operation</li>\r\n	<li>60 Memory with Date &amp; Time</li>\r\n	<li>Body Movement Indicator</li>\r\n	<li>Detects irregular heartbeat</li>\r\n	<li>Blood Pressure Level Indicator</li>\r\n	<li>Large Cuff(22-42)cm</li>\r\n	<li>Average of last 3 reading</li>\r\n</ul>\r\n</div>\r\n</div>\r\n</div>', 5, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-08-31 09:02:52', NULL, NULL, NULL, 60, 120, ''),
(4, 4, 500, '<ul>\r\n	<li><span style=\"font-size:large\">3 dusters with removable handle3 dusters with removable handle</span></li>\r\n	<li><span style=\"font-size:large\">1 Empty Multipurpose spray Bottle for soap &amp; Liquid</span></li>\r\n	<li><span style=\"font-size:large\">360 degree rotation</span></li>\r\n	<li><span style=\"font-size:large\">Cleans all kinds of surface in very short time</span></li>\r\n	<li><span style=\"font-size:large\">Powered by 4 x AA batteries (not included)</span></li>\r\n</ul>', 33, NULL, 'general', '84.NICEYARD-Soft-Microfiber-Window-Bookshelf-Dust-Cleaner-Brush-For-Home-Furniture-Car-Multifunctional-Electric-Feather-Duster.jpg_q50.webp', NULL, NULL, NULL, NULL, '2020-08-31 09:11:33', NULL, NULL, NULL, 60, 120, ''),
(5, 5, 500, NULL, 44, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-08-31 09:19:04', NULL, NULL, NULL, 60, 120, ''),
(6, 6, 500, '<p>Parameters:<br />\r\nMaterial:&nbsp;stainless&nbsp;steel;&nbsp;plastic<br />\r\nWeight:&nbsp;about&nbsp;600g</p>\r\n\r\n<p>List:<br />\r\nShredder&nbsp;*&nbsp;3<br />\r\nSlicer&nbsp;*&nbsp;2<br />\r\nFlower&nbsp;Cutter&nbsp;*&nbsp;1<br />\r\nGarlic&nbsp;Grinding&nbsp;*&nbsp;1<br />\r\nParing&nbsp;Cutter&nbsp;*&nbsp;1</p>\r\n\r\n<p>Food&nbsp;Container&nbsp;*&nbsp;1</p>\r\n\r\n<p>বিশেষ দ্রষ্টব্য : ব্লেড সাদা-কালো দুইটা কালার</p>', NULL, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-08-31 09:24:42', NULL, NULL, NULL, 60, 120, ''),
(7, 7, 500, '<ul>\r\n	<li>Color:Purple,Blue,Red,Green,Yellow</li>\r\n	<li>Material: ABS plastic + stainless steel</li>\r\n	<li>Dust capacity:0.5L</li>\r\n	<li>Weight:900G</li>\r\n	<li>Pole length:100CM</li>\r\n	<li>Size:31*19.7*6CM</li>\r\n	<li>Package include:1Pcs&nbsp;Sweeping machine.</li>\r\n</ul>', 50, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-09 16:26:53', NULL, NULL, NULL, 70, 120, ''),
(8, 8, 400, '<table border=\"0\" cellpadding=\"0\" cellspacing=\"1\" style=\"height:245px; width:836px\">\r\n	<tbody>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">Product name</td>\r\n			<td style=\"vertical-align:top\">\r\n			<p>USSE BPA Free FDA Food Grade&nbsp; Cooking Tools Flower Spill Stopper silicone pan cover</p>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">Color</td>\r\n			<td style=\"vertical-align:top\">Any color is available</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">Material</td>\r\n			<td style=\"vertical-align:top\">100% First-class silicone</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">Certification</td>\r\n			<td style=\"vertical-align:top\">FDA, LFGB, SGS,ISO9001</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">Price</td>\r\n			<td style=\"vertical-align:top\">Factory price, large price favorably</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">logo</td>\r\n			<td style=\"vertical-align:top\">Can be as your requirement</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">OEM</td>\r\n			<td style=\"vertical-align:top\">Welcome</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"vertical-align:top\">Package</td>\r\n			<td style=\"vertical-align:top\">\r\n			<p>Opp bag, can be customized</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>', 5, NULL, 'general', '93.milk-2.webp', NULL, NULL, NULL, NULL, '2020-09-03 09:23:09', NULL, NULL, NULL, 60, 120, ''),
(9, 9, 1100, '<p>product Description<br />\r\nAcupoint massage<br />\r\nAutomatic heater<br />\r\nInfrared care<br />\r\nBubble impact<br />\r\nVibration massage<br />\r\nMagnet therapy<br />\r\nPRODUCT DETAILS:</p>\r\n\r\n<p>Voltage: AC 240V<br />\r\nFrequency: 60HZ<br />\r\nPower: 350W<br />\r\nNet weight: 3kg<br />\r\nHighest temperature: 50&ordm;C<br />\r\nApprox water amount: 4.5L</p>', 50, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 09:40:34', NULL, NULL, NULL, 70, 120, ''),
(10, 10, 0, '<div class=\"active animated show slideInUp tab-pane\" id=\"guarantees\">আমরা সারা বাংলাদেশে আপনার (নিকটস্থ) সুন্দরবন, জননী ও করোতোয়া কুরিয়ারের</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">মাধ্যমে ডেলিভারী করে থাকি।<br />\r\n✔ ঢাকা মেট্রোপলিটন এরিয়ার ভিতরে ক্যাশ অন ডেলিভারী চার্জ 7০টাকা,</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">যা পন্য বুঝে নেয়ার সময় পরিশোধ করতে হবে।</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">২৪ থেকে ৪৮ ঘন্টার মধ্যে ডেলিভারী করা হয়ে থাকে।<br />\r\n✔ ঢাকা সিটির বাহিরে ডেলিভারী চার্জ 130&nbsp;টাকা।</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">এক্ষেত্রে পণ্যের সম্পূর্ণ মূল্য অথবা ২০০ অগ্রিম বিকাশ করে অর্ডারটি</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">কনফার্ম করতে হবে।</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">অবশিষ্ট মূল্য কুরিয়ার অফিস থেকে পণ্য বুঝে নেওয়ার সময় কুরিয়ার আফিসে পেমেন্ট করতে হবে।</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">৪৮ থেকে ৭২ ঘন্টার মধ্যে ডেলিভারী করা হয়ে থাকে।<br />\r\n✔এছাড়া অনলাইনে অগ্রীম মুল্য প্রদানের ক্ষেত্রে বিকাশ, রকেট অথবা অনলাইন ব্যাংকিং এর মাধ্যমে</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">ডেবিট/ক্রেডিট কার্ড এর মাধ্যমে পেমেন্ট করার সুবিধা রয়েছে।<br />\r\nফেসবুকে অর্ডার করতেঃ আপনার পছন্দের পণ্যটি অর্ডার করতে Product Link অথবা আপনার পছন্দের</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">পণ্যটির ছবি বা স্ক্রিনশট আমাদের অফিসিয়াল পেজ https://www.facebook.com/tazibd.com এ শেয়ার করুন</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">এবং সাথে আপনার নাম, মোবাইল নাম্বার, ই-মেইল এবং ঠিকানা লিখতে ভুলবেন না।</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">আমাদের কাষ্টমার কেয়ার প্রতিনিধি মোবাইলের ম্যাসেজ বা ই-মেইল এর মাধ্যমে আপনার অর্ডারটি confirm করে নিবেন।<br />\r\nমোবাইলে অর্ডার করতেঃ আপনার পছন্দকৃত পণ্যটির নাম/কোড নাম্বার এর সাথে আপনার নাম, এবং ঠিকানা আমাদের</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">হটলাইন নাম্বারে +8801758902942&nbsp; সেন্ড করুন। আমাদের কাষ্টমার কেয়ার প্রতিনিধি</div>\r\n\r\n<div class=\"active animated show slideInUp tab-pane\">মোবাইলের ম্যাসেজ এর মাধ্যমে আপনার অর্ডারটি confirm করে নিবেন।<br />\r\nআপনার বিশেষ কিছু জানার থাকলে আমাদের হটলাইন নাম্বারে (&nbsp; অথবা&nbsp; ) যে কোন সময় ফোন করে কথা বলতে</div>', 20, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 12:51:36', NULL, NULL, NULL, 60, 120, ''),
(11, 11, 0, '<div class=\"active tab-pane\" id=\"tearm\">\r\n<div class=\"product-tab\">\r\n<div class=\"container\">\r\n<div class=\"tab-content\" id=\"myTabContent\">&nbsp;</div>\r\n</div>\r\n</div>\r\n</div>', 20, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 13:09:31', NULL, NULL, NULL, 70, 120, ''),
(12, 12, 800, NULL, 12, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 13:05:18', NULL, NULL, NULL, 70, 120, ''),
(14, 14, 800, NULL, NULL, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 14:42:58', NULL, NULL, NULL, 70, 120, ''),
(15, 15, 700, NULL, 30, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 14:50:00', NULL, NULL, NULL, 70, 120, ''),
(16, 16, 1000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nখিমার -১৪৫০ টাকা<br />\r\nসেট ইনার -২৫০০<br />\r\nসেট স্কাট -২২০০</p>', 20, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 15:41:28', NULL, NULL, NULL, 70, 120, ''),
(17, 17, 1000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nখিমার -১৪৫০ টাকা<br />\r\nসেট ইনার -২৫০০<br />\r\nসেট স্কাট -২২০০</p>', 20, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 15:53:55', NULL, NULL, NULL, 70, 120, ''),
(18, 18, 1000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nখিমার -১৪৫০ টাকা<br />\r\nসেট ইনার -২৫০০<br />\r\nসেট স্কাট -২২০০</p>', 15, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-10-29 14:15:04', NULL, NULL, NULL, 70, 120, ''),
(19, 19, 2000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nখিমার -2950&nbsp;টাকা<br />\r\nসেট ইনার -২৫০০<br />\r\nসেট স্কাট -২২০০</p>', 15, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-10-29 14:15:14', NULL, NULL, NULL, 70, 120, ''),
(20, 20, 3000, NULL, 30, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 16:19:17', NULL, NULL, NULL, 70, 120, ''),
(21, 21, 2000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nসাইজ: ,48,50,52,54,56,58,60<br />\r\nআমাদের কোন বোরকার সাথে হিজাব নাই। হিজাব নিতে চাইলে আলাদা দাম দিতে হবে</p>', 10, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 16:47:52', NULL, NULL, NULL, 70, 120, ''),
(22, 22, 2500, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nসাইজ: ,48,50,52,54,56,58,60<br />\r\nআমাদের কোন বোরকার সাথে হিজাব নাই। হিজাব নিতে চাইলে আলাদা দাম দিতে হবে</p>', 10, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-09-03 16:47:39', NULL, NULL, NULL, 60, 120, ''),
(23, 23, 1000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nসাইজ: ,48,50,52,54,56,58,60<br />\r\nআমাদের কোন বোরকার সাথে হিজাব নাই। হিজাব নিতে চাইলে আলাদা দাম দিতে হবে</p>', 10, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-10-29 14:18:17', NULL, NULL, NULL, 60, 120, ''),
(24, 24, 1000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nসাইজ: ,48,50,52,54,56,58,60<br />\r\nআমাদের কোন বোরকার সাথে হিজাব নাই। হিজাব নিতে চাইলে আলাদা দাম দিতে হবে</p>', 10, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-10-29 14:16:15', NULL, NULL, NULL, 70, 120, ''),
(25, 25, 1000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nসাইজ: ,48,50,52,54,56,58,60<br />\r\nআমাদের কোন বোরকার সাথে হিজাব নাই। হিজাব নিতে চাইলে আলাদা দাম দিতে হবে</p>', 10, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-10-29 14:15:58', NULL, NULL, NULL, 70, 120, ''),
(26, 26, 1000, '<p>ফেব্রিক-ডায়মন্ড জর্জেট<br />\r\nসাইজ: ,48,50,52,54,56,58,60<br />\r\nআমাদের কোন বোরকার সাথে হিজাব নাই। হিজাব নিতে চাইলে আলাদা দাম দিতে হবে</p>', 10, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-10-29 14:52:06', NULL, NULL, NULL, 70, 120, ''),
(27, 27, 900, '<p>&gt;Heart rate monitor<br />\r\n&gt;ouch key and press key operated<br />\r\n&gt;Gesture control, turn the wrist lit screen<br />\r\n&gt; Accurate heart rate accurately by PPG sensor<br />\r\n&gt;Keep connected with a smartphone through Bluetooth<br />\r\n&gt;Time, Heart rate monitor, Pedometer, distance monitor<br />\r\n&gt;Calorie monitor, Alarm clock, sleep monitor, camera remote</p>', 20, NULL, 'general', NULL, NULL, NULL, NULL, NULL, '2020-10-29 14:52:23', NULL, NULL, NULL, 70, 120, '');

-- --------------------------------------------------------

--
-- Table structure for table `review`
--

CREATE TABLE `review` (
  `review_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `review_active` int(11) NOT NULL DEFAULT 0,
  `created_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `review`
--

INSERT INTO `review` (`review_id`, `product_id`, `name`, `email`, `comment`, `rating`, `review_active`, `created_time`) VALUES
(1, 84, 'sujon', 'suzonice15@gmail.com', 'good', '5', 0, NULL),
(2, 84, 'mitul', 'fjjfjf@fmao.com', 'ok		', '3', 1, '2019-09-20 05:40:29'),
(3, 169, 'suzon', 'suzonice15@gmail.com', 'ttt', '5', 1, '2019-09-19 14:14:06'),
(4, 169, 'suzon', 'suzonice15@gmail.com', 'hh				', '5', 1, '2019-09-20 05:40:22'),
(5, 169, 'suzon', 'suzonice15@gmail.com', 'ok', '3', 1, '2019-09-19 14:17:05'),
(8, 180, 'sumon', 'suzonice15@gmail.com', 'ddd', '5', 0, '2019-09-20 09:42:36'),
(9, 167, 'mitul', 'suzonice1@gmal.com', 'hhh', '5', 0, '2019-09-20 16:28:07'),
(10, 169, 'raihan', 'mitul@gmail.com', 'ddd', '5', 1, '2019-09-20 16:30:26'),
(11, 169, 'abu', 'abu@gmail.com', 'ok\n', '5', 1, '2019-09-20 16:34:44'),
(12, 178, 'suzon', 'suzonice15@gmail.com', 'ok', '5', 1, '2019-09-22 09:57:49'),
(13, 178, 'mitul', 'suzonice15@gmail.com', 'nice		2e', '5', 1, '2019-10-10 02:13:18'),
(14, 167, 'Full HD 1080P স্পোর্টস অ্যাকশন ওয়াটারপ্রুফ ক্যামেরা 12MP - Black', 'anisurrups@gmail.com', 'kk		', '5', 1, '2019-11-18 05:24:57'),
(15, 186, 'Asia', 'anisur134@gmail.com', 'ok', '5', 1, '2019-10-17 13:45:07');

-- --------------------------------------------------------

--
-- Table structure for table `tryorder`
--

CREATE TABLE `tryorder` (
  `tryorder_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_qnt` int(11) NOT NULL,
  `product_price` float NOT NULL,
  `product_image` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tryorder`
--

INSERT INTO `tryorder` (`tryorder_id`, `order_id`, `product_name`, `product_qnt`, `product_price`, `product_image`) VALUES
(273, 281, ' Arctic এয়ার কুলার আলট্রা', 1, 2500, 'http://localhost/sopnershop/uploads/20-24-04-05-09-2019-Ultra-New-Arctic-Air-Cooler_thumb.jpg'),
(274, 282, ' Arctic এয়ার কুলার আলট্রা', 1, 2500, 'http://localhost/sopnershop/uploads/20-24-04-05-09-2019-Ultra-New-Arctic-Air-Cooler_thumb.jpg'),
(272, 280, ' Arctic এয়ার কুলার আলট্রা', 1, 2500, 'http://localhost/sopnershop/uploads/20-24-04-05-09-2019-Ultra-New-Arctic-Air-Cooler_thumb.jpg'),
(271, 278, 'জাতীয় সংসদ ভবন রেপ্লিকা ভাস্কর্য', 1, 790, 'http://localhost/sopnershop/uploads/54-35-06-17-10-2019-assembly_thumb.jpg'),
(270, 275, 'WiFi IP Security Camera wireless CCTV Camera for home and office security', 1, 1990, 'http://localhost/sopnershop/uploads/1571830915wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-7_thumb.jpg'),
(268, 271, 'Oma Fitness 1916 CAM ', 1, 100, 'http://localhost/sopnershop/uploads/10-26-06-17-10-2019-oma-fit_thumb.jpg'),
(269, 273, 'Liqua Gold Leaf ', 1, 190, 'http://localhost/sopnershop/uploads/12-56-05-17-10-2019-Liqua-Gold-Leaf_thumb.jpg'),
(267, 271, 'WiFi IP Security Camera wireless CCTV Camera for home and office security', 1, 1990, 'http://localhost/sopnershop/uploads/1571830915wifi-ip-security-camera-wireless-cctv-camera-for-home-and-office-security 1001-7_thumb.jpg'),
(266, 271, 'KONIYCOI KT-2100MV', 2, 2250, 'http://localhost/sopnershop/uploads/29-50-06-17-10-2019-head_thumb.jpg'),
(264, 271, 'Liqua Gold Leaf ', 1, 190, 'http://localhost/sopnershop/uploads/12-56-05-17-10-2019-Liqua-Gold-Leaf_thumb.jpg'),
(265, 271, 'জাতীয় সংসদ ভবন রেপ্লিকা ভাস্কর্য', 1, 100, 'http://localhost/sopnershop/uploads/54-35-06-17-10-2019-assembly_thumb.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `courier`
--
ALTER TABLE `courier`
  ADD PRIMARY KEY (`courier_id`);

--
-- Indexes for table `deafult_seating`
--
ALTER TABLE `deafult_seating`
  ADD PRIMARY KEY (`default_setting_id`);

--
-- Indexes for table `homeslider`
--
ALTER TABLE `homeslider`
  ADD PRIMARY KEY (`homeslider_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`media_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`newsletter_id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`option_id`);

--
-- Indexes for table `order_data`
--
ALTER TABLE `order_data`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `product_id` (`product_id`,`product_name`(191),`sku`(191));

--
-- Indexes for table `product_category_relation`
--
ALTER TABLE `product_category_relation`
  ADD PRIMARY KEY (`product_category_relation_id`),
  ADD KEY `product_id` (`product_id`,`category_id`);

--
-- Indexes for table `product_relation`
--
ALTER TABLE `product_relation`
  ADD PRIMARY KEY (`product_relation_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `tryorder`
--
ALTER TABLE `tryorder`
  ADD PRIMARY KEY (`tryorder_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `courier`
--
ALTER TABLE `courier`
  MODIFY `courier_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `deafult_seating`
--
ALTER TABLE `deafult_seating`
  MODIFY `default_setting_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `homeslider`
--
ALTER TABLE `homeslider`
  MODIFY `homeslider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `media_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `newsletter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `order_data`
--
ALTER TABLE `order_data`
  MODIFY `order_id` bigint(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `product_category_relation`
--
ALTER TABLE `product_category_relation`
  MODIFY `product_category_relation_id` bigint(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `product_relation`
--
ALTER TABLE `product_relation`
  MODIFY `product_relation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tryorder`
--
ALTER TABLE `tryorder`
  MODIFY `tryorder_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=275;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
